ClubStyle Garage replacement set - 2026-08-27

Replace these files in the project with the matching paths.

What this set implements:
- searchable quick customer selector in Add/Edit Work
- detailed Customer Search popup with filters
- Add Customer popup; newly created customer is selected immediately
- Vehicle moved to its own row
- Existing Vehicle / Free Text vehicle modes
- garage_work_items.customer + vehicle_text support
- existing historical vehicle-linked work can infer customer when edited
- free-text work appears in Work dashboard
- Work dashboard mobile cards on small screens
- Work modal and Add Customer popup optimized for iPhone/small screens
- global select/dropdown styling through app/globals.css
- responsive top navigation on small screens

Directus permissions required for the app/service token:
- garage_work_items: read/create/update customer and vehicle_text
- garage_customers: read/create fields used by customer API
- garage_vehicles: read customer relation (used for older vehicle-specific add-work page)

Important:
- This set does NOT yet add the Parts or Billing UI. The database schema is ready for those, and they can be built next without changing this Work/customer structure.
